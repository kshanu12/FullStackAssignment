

import { ExtractJwt, Strategy } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import { jwtSecret } from 'src/utils/contants';
import * as dotenv from "dotenv";
dotenv.config();

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
        jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
        ignoreExpiration: false,
        secretOrKey: process.env.JWT_SECRET,
    })
    
  }

  async validate(username: string, password: string): Promise<any> {
    return 'sucess'
}


// super({
    //   jwtFromRequest: ExtractJwt.fromExtractors([
    //     JwtStrategy.extractJWT,
    //     ExtractJwt.fromAuthHeaderAsBearerToken(),
    //   ]),
    //   secretOrKey: jwtSecret,
    // });



    
//   private static extractJWT(req: Request): string | null {
//     if (req.cookies && 'token' in req.cookies) {
//       return req.cookies.token;
//     }
//     return null;
//   }


//   async validate(payload: { id:number,email: string;}) {
//     return payload;
//   }
}




// // import { Injectable } from "@nestjs/common";
// // import { PassportStrategy } from "@nestjs/passport";
// // import { ExtractJwt, Strategy } from "passport-jwt";
// // import { jwtSecret } from "src/utils/contants";
// import { Injectable } from "@nestjs/common";
// import { PassportStrategy } from "@nestjs/passport";
// import { ExtractJwt, Strategy } from "passport-jwt";
// import { jwtSecret } from "src/utils/contants";
// import { Request,Response } from "express";


// @Injectable()
// export class JwtStrategy extends PassportStrategy(Strategy) {
//   constructor() {
//     super({
//       jwtFromRequest: ExtractJwt.fromExtractors([
//         JwtStrategy.extractJWT,
//         ExtractJwt.fromAuthHeaderAsBearerToken()
//       ]),
//       secretOrKey: jwtSecret,
//     });
//   }

  

//   private static extractJWT(req: Request): string | null {
//     if (req.cookies && 'token' in req.cookies) {
//       return req.cookies.token;
//     }
//     return null;
//   }
 

//   async validate(payload: { email: string; passsword: string }) {
//     console.log(payload)
//     return payload;
//   }
// }






// @Injectable()
// export class JwtStrategy extends PassportStrategy(Strategy) {

//     constructor() {
//         super({
//             jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
//             ignoreExpiration: false,
//             secretOrKey: 'test'
//         })
//     }


//     async validate(username: string, password: string): Promise<any> {
//         return 'sucess'
//     }
// }