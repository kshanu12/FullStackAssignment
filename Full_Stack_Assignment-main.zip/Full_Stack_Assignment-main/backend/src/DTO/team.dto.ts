import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsNumber, IsString, Length } from "class-validator";

export class TeamDto{

    public id:number

    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    public name:string



    @IsNotEmpty()
    @IsNumber()
    @ApiProperty()
    public projectId:number
    

}

