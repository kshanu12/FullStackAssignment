import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsString, Length } from "class-validator";

export class ResetDto{

    @IsNotEmpty()
    @IsEmail()
    @IsString()
    @ApiProperty()
    public email:string



    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    public oldPassword:string


    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    public newPassword:string

}

