import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsNotEmpty, IsString, Length } from "class-validator";

export class LoginDto{

    public id:number

    @IsNotEmpty()
    @IsString()
    @IsEmail()
    @ApiProperty()
    public email:string



    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    @Length(3,20,{message:'Password mus be bewteen 3 to 20 chars'})
    public password :string
}

