import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsEnum, IsNotEmpty, IsString, Length } from "class-validator";



enum _role {
    ADMIN = 'ADMIN',
    ALL = 'ALL',
  }


export class AuthDto{





    public id:number



    @ApiProperty()
    public first_name:string

    @ApiProperty()
    public last_name:string

    @ApiProperty({
        enum:_role,
        description:'Select role as ADMIN ,ALL'
    })
    @IsEnum(_role)
    public role:string

    @IsNotEmpty()
    @IsString()
    @IsEmail()
    @ApiProperty()
    public email:string



    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    @Length(3,20,{message:'Password mus be bewteen 3 to 20 chars'})
    public password :string

    @IsNotEmpty()
    @ApiProperty()
    public teamId :number
}

