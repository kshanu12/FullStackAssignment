import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaClient, User } from '@prisma/client';
import { JwtService } from '@nestjs/jwt';
import { Request, Response } from 'express';
import { AuthDto } from 'src/DTO/auth.dto';
import { ResetDto } from 'src/DTO/resetPassword.dto';
import { PrismaService } from 'src/prisma/prisma.service';
import { emit } from 'process';

@Injectable()
export class UserService {

    constructor(private prisma: PrismaService, private jwt: JwtService) { }

    async resetUser(_reset: ResetDto, req: Request, res: Response) {
        try {
            const getData = await this.prisma.user.findUnique({
                where: {
                    email: _reset.email
                }
            })
            if (!getData) {
                return res.status(404).send({
                    message: "Failed",
                    response: "User doesn't exist"
                })
            } else {
                const ifUser = await bcrypt.compare(_reset.oldPassword, getData.hashPassword);
                if (ifUser) {
                    const updatePassword = await this.prisma.user.update({
                        where: { email: _reset.email },
                        data: {
                            hashPassword: _reset.newPassword
                        }
                    })
                } else { return res.status(201).send({ message: "User doesn't exist or old password is not correct" }); }
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }
    
    async inserUser(_user: AuthDto, req: Request, res: Response) {
        try {
            const foundUser = await this.prisma.user.findUnique({ where: { email: _user.email } })
            if (foundUser) {
                throw new BadRequestException('Email already exists')
            }
            else {
                const { first_name, last_name, role, email, password ,teamId} = _user;
                const hashPassword = await this.hashedPassword(password)
                const result = await this.prisma.user.create({
                    data: {
                        first_name: first_name,
                        last_name: last_name,
                        role: role,
                        email: email,
                        hashPassword: hashPassword,
                        teamId: teamId
                    }
                })
                return res.status(200).send({ message: 'Data Inserted Sucessfully', data: result })

            }
        }
        catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })

        }
    }



    async getUser(id: number, req: Request, res: Response) {
        try {
            const foundUser = await this.prisma.user.findUnique({ where: { Id: id } })
            if (foundUser) {
                return res.status(200).send({
                    message: foundUser
                })
            } else {
                return res.status(201).send({
                    message: "User not found"
                })
            }
        } catch (error) {
            return res.status(201).send({
                message: "Error has been occured",
                error: error
            })
        }
    }




    async getAll(req: Request, res: Response) {
        try {
            const allUser = await this.prisma.user.findMany()
            if (allUser) {
                return res.status(200).send({
                    message: allUser
                })
            }
            else {
                return res.status(201).send({
                    message: "Database is empty"
                })
            }
        }
        catch (e) {
            return res.status(201).send({
                message: "Error Ocuured",
                error: e
            })
        }
        // throw new Error("Method not implemented.");
    }



    async hashedPassword(password: string) {
        const saltOrRound = 10
        const hashPassword = await bcrypt.hash(password, saltOrRound)
        return hashPassword;
    }


    async comparePassword(args: { password: string, hash: string }) {
        return await bcrypt.compare(args.password, args.hash);
    }



}
