import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaClient, User } from '@prisma/client';
import { JwtService } from '@nestjs/jwt';
import { Request, Response } from 'express';
import { PrismaService } from 'src/prisma/prisma.service';
import { TeamDto } from 'src/DTO/team.dto';

@Injectable()
export class TeamService {
    constructor(private prisma: PrismaService) { }

    async getTeamById(id: number, req: any, res: any) {
        try {
            const result = await this.prisma.team.findUnique({
                where: { Id: id }
            })
            if (result)
                return res.status(200).send({ result })
            else {
                return res.status(201).send({ message: "Data not found" })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }

    async getAllTeam(req: Request, res: Response) {
        try {
            const result = await this.prisma.team.findMany()
            if (result)
                return res.status(200).send({ result })
            else {
                return res.status(201).send({ Message: "Data Not Found" })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }

    async insertTeam(data: TeamDto, req: any, res: any) {
        try {
            const foundTeam = await this.prisma.team.findUnique({ where: { name: data.name } })
            if (foundTeam) {
                return res.status(200).send({ message: 'Title already exists' })
            }
            else {
                const foundProject = await this.prisma.project.findUnique({ where: { Id: data.projectId } })
                if (!foundProject) {
                    return res.status(200).send({ message: "Project doesn't exists" })
                }
                else {
                    const prisma = new PrismaClient()
                    const result = await prisma.team.create({ data })
                    return res.status(200).send({ message: 'Data Inserted Sucessfully', data: result })
                }
            }
        }
        catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })

        }
    }



}
