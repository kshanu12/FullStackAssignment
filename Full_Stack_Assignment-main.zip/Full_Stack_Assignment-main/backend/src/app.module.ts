import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { ConfigModule } from "@nestjs/config";
import { AuthModule } from "./auth/auth.module";
import { JwtModule } from "@nestjs/jwt";
import { PrismaModule } from "./prisma/prisma.module";
import { UserModule } from "./User/user.module";
import { ProjectModule } from "./Project/project.module";
import { TeamModule } from "./Team/team.module";
import { EpicModule } from "./Epic/epic.module";
import { JwtStrategy } from "./auth/jwt.strategy";
import { AuditMiddleware } from "./Audit/apiHistory.middleware";
import { AuditLogsService } from "./Audit/audit.service";
import { ThrottlerGuard, ThrottlerModule } from "@nestjs/throttler";
import { APP_GUARD } from "@nestjs/core";
import { IssueModule } from "./Issue/issue.module";
import { StatusModule } from "./Status/status.module";
import { PriorityModule } from "./Prioritry/priority.module";
import { TypeModule } from "./Type/type.module";
import { AuditLogModule } from "./Audit/audit.module";
// import { ApiHistoryMiddleware } from "./apiHistory.middleware";



@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    JwtModule,
    AuthModule,
    IssueModule,
    PrismaModule,
    TypeModule,
    UserModule,
    StatusModule,
    TeamModule,
    ProjectModule,
    EpicModule,
    PriorityModule,
    AuditLogModule,
    ThrottlerModule.forRoot({
      ttl: 60,
      limit: 5000,
    })
  ],

  controllers: [AppController],
  providers: [AppService, JwtStrategy, AuditLogsService, {
    provide: APP_GUARD,
    useClass: ThrottlerGuard,
  }],
})
export class AppModule implements NestModule {
  constructor(private readonly auditLogsService: AuditLogsService) { }

  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AuditMiddleware).forRoutes('*');
  }
}
// export class AppModule {}
// export class AppModule implements NestModule {
//   configure(consumer: MiddlewareConsumer) {
//     consumer.apply(ApiHistoryMiddleware).forRoutes('*');
//   }
// }


