import { Module } from "@nestjs/common";
import { TypeService } from "./type.service";
import { PrismaService } from "../prisma/prisma.service";
import { TypeController } from "./type.controller";
import { JwtService } from "@nestjs/jwt";
 
@Module({
    providers: [TypeService, PrismaService, JwtService],
    exports: [TypeService],
    controllers: [TypeController],
})
export class TypeModule { }