import { PrismaClient, Type } from '@prisma/client'
const prisma = new PrismaClient()
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
// import { JwtAuthGuard } from '../auth/auth.guard';
// import { TypeDto } from './type.dto';
// import { TypeService } from './type.service';
import { ApiBody, ApiTags } from '@nestjs/swagger';
import { TypeService } from './type.service';
// import { UpdateTypeDto } from './type.updateDto';
 
@Controller('type')
@ApiTags('Type')
export class TypeController {
    constructor(private readonly typeService: TypeService) { }
 
    @Get()
    // @UseGuards(JwtAuthGuard)
    getAll(): Promise<Type[] | object> {
        return this.typeService.findAll();
    }
}