import { Controller, Request, Post, UseGuards, Get, Body, Req, Res, Param, Patch, Delete } from "@nestjs/common";
import { ApiBody, ApiTags } from "@nestjs/swagger";

import { ProjectDto } from "src/DTO/project.dto";
import { IssueService } from "./issue.service";
import { IssueDto } from "../DTO/Issue.dto";
import { IssueUpdateDto } from "../DTO/Update.Issue.dto";


@ApiTags("Issue")
@Controller('issue')
export class IssueController {


    constructor(private readonly issueService: IssueService) { }

    @Get("issue/:id")
    getbyId(
        @Param('id') id: number,
        @Req() req, @Res() res,
    ) {
        id = Number(id)
        return this.issueService.findEpicById(id, req, res);
    }



    @Get('allIssue')
    getAllIssue(@Req() req, @Res() res) {
        return this.issueService.getIssueAll(req, res);
    }

    @Post('create')
    createIssue(
        @Body() _issue: IssueDto,
        @Req() req, @Res() res,
    ) {
        return this.issueService.insertData(_issue, req, res);
    }


    @Post('filter')
    filterData(
        @Body() _issue: IssueUpdateDto,
        @Req() req, @Res() res,
    ) {
        return this.issueService.issueFilter(_issue, req, res);
    }


    @Patch(':id')
    updateDataWithPatch(
        @Param('id') id: number,
        @Body() _issue: IssueUpdateDto,
        @Req() req, @Res() res,
    ) {
        return this.issueService.UpdateDataPatch(+id, _issue, req, res);
    }




    @Delete(':id')
    deleteById(
        @Param('id') id: number,
        @Req() req, @Res() res,
    ) {
        return this.issueService.deleteIssueById(+id, req, res)
    }



    @Get('projectId/:projectId')
    getIssueByProjectId(
        @Param('projectId') projectId: number,
        @Req() req, @Res() res,
    ) {

        return this.issueService.getIssueWithProjectId(+projectId, req, res)
    }



}
