import { PrismaClient, Status } from '@prisma/client'
import {Req, Res } from "@nestjs/common";

const prisma = new PrismaClient()
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
// import { JwtAuthGuard } from '../auth/auth.guard';
import { StatusService } from './status.service';
import { ApiBody, ApiTags } from '@nestjs/swagger';
 
@Controller('status')
@ApiTags('Status')
export class StatusController {
    constructor(private readonly statusService: StatusService) { }
 
    @Get()
    // @UseGuards(JwtAuthGuard)
    getAll(): Promise<Status[] | object> {
        return this.statusService.findAll();
    }
}