
import { Injectable, NestMiddleware } from '@nestjs/common';
import { AuditLogsService } from './audit.service';
import { ExtractJwt } from 'passport-jwt';
import { JwtService } from '@nestjs/jwt';
import { jwtSecret } from 'src/utils/contants';
// import { AuditLogsService } from './audit-logs.service';

@Injectable()
export class AuditMiddleware implements NestMiddleware {
    constructor(private auditLogsService: AuditLogsService, private jwtService: JwtService) { }

    async use(req: any, res: any, next: () => void) {
        const token = ExtractJwt.fromAuthHeaderAsBearerToken()(req)
        const user = await this.getUserDetailsFromJWT(this.jwtService, token);
        // console.log(user)
        const Email = req.body.email
        // console.log(Email)
        // console.log(typeof(Email))
        // console.log(user)
        // console.log(user["username"])
        const method = req.method;
        const actionTable = req.originalUrl.split('/')[1];
        const auditUser = Email // assuming user is authenticated and their username is stored in req.user
        const statusCode = res.statusCode;
        const changes = JSON.stringify(req.body);
        const timestamp = new Date();

        // console.log("Audit -> ");

        // console.log(auditUser)
        // console.log("Audit<- end");

        await this.auditLogsService.createAuditLog(
            method,
            actionTable,
            auditUser,
            statusCode,
            changes,
            timestamp,
            req,
            res,
        );

        next();
    }

    async getUserDetailsFromJWT(
        jwtService: JwtService,
        bearerToken: string
    ) {
        if (bearerToken !== undefined && bearerToken !== null) {
            let token = bearerToken.substring(7);
            return await jwtService.decode(token);
        }
        return {
            username: "",
        };
    }
}
