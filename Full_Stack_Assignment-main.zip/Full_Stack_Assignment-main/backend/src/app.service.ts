import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from './prisma/prisma.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { jwtSecret } from './utils/contants';
import { Request, Response } from 'express';
import { LoginDto } from './DTO/login.dto';
require('dotenv').config();


@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }

  constructor(private prisma: PrismaService, private jwtService: JwtService) { }


  async signin(dto: LoginDto, req: Request, res: Response) {
    try {
      const { email, password } = dto
      const foundUser = await this.prisma.user.findUnique({ where: { email } })

      if (!foundUser) {
        return res.status(201).send({
          message: "user not found"
        })
      }

      // delete user.hashedPassword;
      const isMatch = await this.comparePassword({ password, hash: foundUser.hashPassword })
      if (!isMatch) {
        return res.status(201).send({
          message: "user not found"
        })
      }

      const token = await this.signToken({
        id: foundUser.Id,
        username: foundUser.email
      });
      if (!token) {
        return res.status(201).send({
          message: "user not found"
        })
      }

      res.cookie('token', token)
      return res.status(200).send({
        token: token,
        message: "Logged in sucessfully",
        user: foundUser
      });
    } catch (e) {
      return res.status(404).send({
        message: "Error occured",
        error: e
      })
    }

  }


  async signout(req: Request, res: Response) {
    let _token = ""
    const lets_for_token = req.get('cookie')
    if (lets_for_token) {
      const _for_token = lets_for_token.split(';')
      _for_token.forEach(__token => {
        if (__token[0] == 'token' || __token.substring(1, 6) == 'token') { _token = __token.substring(7) }
        else {
          _token = ""
        }
      });
      res.clearCookie('token')
      if (_token.length == 0) {
        return res.status(201).send({ message: "No user Found" })
      }
      else {
        const user = await this.jwtService.decode(_token);//to get the information of user from the jwt string
        return res.status(200).send({
          message: `${user["username"]} has been Logged out scucessfully`
        });
      }
    } else {
      return res.status(201).send({ status: 201, message: "User Not Logged In" })

    }
  }


  async hashedPassword(password: string) {
    const saltOrRound = 10
    const hashPassword = await bcrypt.hash(password, saltOrRound)
    return hashPassword;
  }
  async comparePassword(args: { password: string, hash: string }) {
    return await bcrypt.compare(args.password, args.hash);
  }


  async signToken(args: { id: number, username: string }) {
    const payload = args
    const result = await this.jwtService.signAsync(payload,
      {
        secret: process.env.JWT_SECRET
      }
    );
    return result;
  }
}
