import { DatePicker } from "antd";
import styles from "./epicForm.module.css";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { create } from "domain";
import { getEpicById, postEpic, updateEpic } from "@/method/epic";

function EpicForm() {
  const router = useRouter();
  let typeForm = router.asPath.split("/").splice(-1)[0];
  typeForm = typeForm.charAt(0).toUpperCase() + typeForm.slice(1);
  const projectIdFromPath = Number(router.asPath.split("/")[2]);
  const epicIdFromPath = Number(router.asPath.split("/")[4]);

  const [epic, setEpic] = useState({
    title: "",
    statusId: 1,
    description: "",
    start_date: "",
    end_date: "",
    projectId: projectIdFromPath,
  });
  const [originalState, setOriginalState] = useState({
    title: "",
    statusId: 1,
    description: "",
    start_date: "",
    end_date: "",
    projectId: projectIdFromPath,
  });

  useEffect(() => {
    const fetchData = async () => {
      const res = await getEpicById(Number(epicIdFromPath));
      if (res?.Id !== undefined) {
        setEpic({
          title: res.title,
          statusId: 1,
          description: res.description,
          start_date: new Date(res.start_date).toISOString().substring(0, 10),
          end_date: new Date(res.end_date).toISOString().substring(0, 10),
          projectId: projectIdFromPath,
        });
      }
    };
    if (typeForm !== "Create") fetchData();
  }, [epicIdFromPath]);

  useEffect(() => {
    if (originalState.title === "") {
      setOriginalState(epic);
    }
  }, [epic]);

  const titleHandler = (e: any) => {
    setEpic({ ...epic, title: e.target.value });
  };
  const descHandler = (e: any) => {
    setEpic({ ...epic, description: e.target.value });
  };
  const startDateHandler = (e: any) => {
    setEpic({ ...epic, start_date: e.target.value });
  };
  const endDateHandler = (e: any) => {
    setEpic({ ...epic, end_date: e.target.value });
  };

  const resetHandler = () => {
    setEpic(originalState);
  };

  const submitHandler = () => {
    if (typeForm === "Create") {
      // console.log("before", Number(projectIdFromPath));

      setEpic({ ...epic, projectId: Number(projectIdFromPath) });

      // console.log("after", epic);

      postEpic(epic);
      router.push(`/project/${projectIdFromPath}/epic`);
    } else {
      updateEpic(epicIdFromPath, epic);
      router.push(`/project/${projectIdFromPath}/epic`);
    }
  };

  return (
    <div className={styles.formWrapper}>
      <div className={styles.titleWrapper}>
        <p className={styles.title}>{typeForm} Epic</p>
      </div>
      <div className={styles.contentWrapper}>
        <p className={styles.labels}>
          Title<span className={styles.req}>*</span>
        </p>
        <input
          type="text"
          name="Title"
          id="Title"
          value={epic.title}
          placeholder="Enter Title"
          className={styles.inputBox}
          onChange={titleHandler}
          required
        ></input>

        <p className={styles.labels}>
          {" "}
          Description<span className={styles.req}>*</span>
        </p>
        <textarea
          placeholder="Enter Description"
          onChange={descHandler}
          name="Description"
          id="description"
          value={epic.description}
          className={styles.desc}
          required
        ></textarea>

        <div className={styles.dateWrapper}>
          <div className={styles.dateStart}>
            <label className={styles.labels}>Start Date</label>
            <input
              type="date"
              id="startDateInput"
              onChange={startDateHandler}
              value={epic.start_date}
            ></input>
          </div>
          <div className={styles.dateEnd}>
            <label className={styles.labels}>End Date</label>
            <input
              type="date"
              id="endDateInput"
              onChange={endDateHandler}
              value={epic.end_date}
            ></input>
          </div>
        </div>

        <div className={styles.buttonWrapper}>
          <button className={styles.resetButton} onClick={resetHandler}>
            Reset
          </button>
          <button className={styles.submitButton} onClick={submitHandler}>
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}

export default EpicForm;
