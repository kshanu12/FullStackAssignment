import { Card } from 'antd'
import React from 'react'
import StatusProject from '../statusBarProject'
import Link from 'next/link'

export default function MasterCard(props: { epicId: number, title: string, description: string }) {

    return (
        <>
            <div style={{ padding: "0.5rem" }}>
                <Card style={{ width: "100%" }}>
                    <h3>Project Id : {props.epicId}</h3>
                    <h1>Title : {props.title}</h1>
                    <p>Description : {props.description}</p>

                </Card>

            </div>
        </>
    )
}
