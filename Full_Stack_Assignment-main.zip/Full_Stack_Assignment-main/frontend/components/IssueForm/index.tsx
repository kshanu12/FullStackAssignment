import exp from 'constants'
import React, { useEffect, useState } from 'react'
import { Form, Button, Select, DatePicker } from 'antd'
import styles from "./issueForm.module.css";
import { useForm } from 'antd/es/form/Form'
import { useRouter } from 'next/router'
import { getDataStatus } from '@/method/status';
import { getDataTypes } from '@/method/types';
import { getDataPriority } from '@/method/priority';
import { getIssueDataById, postIssue, updateIssue } from '@/method/issue';
import { getUsersData } from '@/method/users';

// interface issueContainer {
//     title: string,
//     description: string,
//     assignee: string,
//     status: string,
//     type: string,
//     priority: string,
//     story_points: number,
//     start_date: string,
//     end_date: string
// }

// const initialState: issueContainer = {
//     title: "",
//     description: "",
//     assignee: "",
//     status: "",
//     type: "",
//     priority: "",
//     story_points: 0,
//     start_date: "",
//     end_date: ""
// }

type status = {
    Id: number,
    statusId: string[]
}

type types = {
    Id: number,
    tType: string
}

type priority = {
    Id: number,
    PType: string
}

export type users = {
    Id: number,
    first_name: string,
    last_name: string,
    role: string,
    email: string,
    password: string,
    teamId: number
}

function IssueFormComponent() {


    const router = useRouter()
    let typeForm = router.asPath.split('/').splice(-1)[0];
    typeForm = typeForm.charAt(0).toUpperCase() + typeForm.slice(1)
    const projectIdFromPath = Number(router.asPath.split('/')[2]);
    const epicIdFromPath = Number(router.asPath.split('/')[4]);
    const issueIdFormPath = Number(router.asPath.split('/')[6])


    const [issues, setIssues] = useState({
        title: "",
        description: "",
        assigneeId: 0,
        reporterId: 0,
        typeId: 1,
        statusId: 1,
        priorityId: 1,
        start_date: '',
        end_date: '',
        epicId: 0
    });

    const [status, setStatus] = useState([])
    const [types, setTypes] = useState([])
    const [priority, setPriority] = useState([])
    const [users, setUsers] = useState<users[]>([])

    const [originalIssue, setOriginalIssue] = useState({
        title: "",
        description: "",
        assigneeId: 0,
        reporterId: 0,
        typeId: 0,
        statusId: 0,
        priorityId: 0,
        start_date: '',
        end_date: '',
        epicId: epicIdFromPath
    });

    useEffect(() => {
        const fetchData = async () => {
            const res = await getDataStatus();
            let statusNames = []
            statusNames = res.map((statusName: status) => {
                return {
                    id: statusName.Id,
                    title: statusName.statusId[0]
                }
            });
            setStatus(statusNames);
        }
        // if (typeForm !== "Create")
        fetchData();
    }, []);
    // console.log("status", status);

    useEffect(() => {
        const fetchData = async () => {
            const res = await getDataTypes();
            let typesNames = []
            typesNames = res.map((typeName: types) => {
                return {
                    id: typeName.Id,
                    tType: typeName.tType
                }
            });
            setTypes(typesNames);
        }
        // if (typeForm !== "Create")
        fetchData();
    }, []);
    // console.log("types", types);

    useEffect(() => {
        const fetchData = async () => {
            const res = await getDataPriority();
            let typesNames = []
            typesNames = res.map((typeName: priority) => {
                return {
                    id: typeName.Id,
                    PType: typeName.PType
                }
            });
            setPriority(typesNames);
        }
        // if (typeForm !== "Create")
        fetchData();
    }, []);
    // console.log("priority", priority);

    useEffect(() => {
        const fetchData = async () => {
            const res = await getIssueDataById(Number(issueIdFormPath));
            if (res.Id !== undefined) {
                setIssues({
                    title: res.title,
                    description: res.description,
                    assigneeId: res.assigneeId,
                    reporterId: res.reporterId,
                    typeId: res.typeId,
                    statusId: res.statusId,
                    priorityId: res.priorityId,
                    start_date: new Date(res.start_date).toISOString().substring(0, 10),
                    end_date: new Date(res.end_date).toISOString().substring(0, 10),
                    epicId: epicIdFromPath
                })
            }
        }
        if (typeForm !== "Create")
            fetchData();
    }, [issueIdFormPath]);
    // console.log("issue", issues);


    useEffect(() => {
        const fetchData = async () => {
            const res = await getUsersData();
            // console.log("-------------------", res);

            let users = []
            users = res.map((user: users) => {
                return {
                    Id: user.Id,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    role: user.role,
                    email: user.email,
                    password: user.password,
                    teamId: user.teamId
                }
            });
            setUsers(users);
        }
        // if (typeForm !== "Create")
        fetchData();
    }, []);
    console.log("users", users);

    useEffect(() => {
        if (originalIssue.title === '') {
            setOriginalIssue(issues)
        }
    }, [issues])



    const titleHandler = (e: any) => {
        setIssues({ ...issues, title: e.target.value })
    }

    const descHandler = (e: any) => {
        setIssues({ ...issues, description: e.target.value })
    }

    const assigneeHandler = (e: any) => {
        setIssues({ ...issues, assigneeId: Number(e.target.value) })
        console.log(e.target.value);
    }


    const statusHandler = (e: any) => {
        // console.log("------------------", issues.statusId);
        setIssues({ ...issues, statusId: Number(e.target.value) })
    }

    const typeHandler = (e: any) => {
        // console.log("------------------", issues.typeId);
        setIssues({ ...issues, typeId: Number(e.target.value) })
    }

    const priorityHandler = (e: any) => {
        // console.log("------------------", issues.priorityId);

        setIssues({ ...issues, priorityId: Number(e.target.value) })
    }

    const startdateHandler = (e: any) => {
        setIssues({ ...issues, start_date: e.target.value })
    }

    const enddateHandler = (e: any) => {
        setIssues({ ...issues, end_date: e.target.value })
    }

    const resetHandler = () => {
        setIssues(originalIssue)
    }

    useEffect(() => {
        setIssues({ ...issues, epicId: Number(epicIdFromPath) })
    }, [epicIdFromPath])

    const submitHandler = () => {
        if (typeForm === "Create") {
            console.log("before", Number(epicIdFromPath));

            setIssues({ ...issues, epicId: Number(epicIdFromPath) })

            // console.log("after", epic);

            postIssue(issues)
            router.push(`/project/${projectIdFromPath}/epic/${epicIdFromPath}/issues/${issueIdFormPath}`)
        }
        else {
            updateIssue(issueIdFormPath, issues)
            router.push(`/project/${projectIdFromPath}/epic/${epicIdFromPath}/issues/${issueIdFormPath}`)
        }
    }

    return (
        <div className={styles.boxForm}>
            <div className={`${styles.issueHeader} ${styles.heading}`}>{typeForm} Issue</div>
            <hr></hr>
            <Form >
                <p className={styles.leftPadding}>Title<span className={styles.asterisk}>*</span></p>
                <input className={styles.titlePlaceholder}
                    name='title'
                    value={issues.title}
                    onChange={titleHandler}
                    type='text' placeholder='name@deloitte.com'
                    required>
                </input>

                <p className={styles.leftPadding}>Description<span className={styles.asterisk}>*</span></p>
                <textarea className={styles.desc}
                    name='description'
                    value={issues.description}
                    onChange={descHandler}
                    placeholder='Description'
                    required>
                </textarea>

                <div className={styles.flexing}>

                    <span className='wrapLeft' style={{ "float": "left" }}>
                        <p className={styles.leftPadding}>Assignee<span className={styles.asterisk}>*</span></p>
                        <select className={styles.status}
                            name="Assignee"
                            value={issues.assigneeId}
                            onChange={assigneeHandler}
                            required
                        >
                            <option value="select" selected disabled>select</option>
                            {users.map((user: users) => <option value={user.Id} >{user.first_name + " " + user.last_name}</option>)}
                        </select>
                    </span>

                    <span className='wrapRight' style={{ "float": "right" }}>
                        <p className={styles.leftPadding}>Status<span className={styles.asterisk}>*</span></p>
                        <select className={styles.status}
                            name="status"
                            value={issues.statusId}
                            onChange={statusHandler}
                            required
                        >
                            <option value="select" selected disabled>select</option>
                            {status.map((item: {
                                id: number,
                                title: string
                            }) => <option value={item.id} >{item.title}</option>)}
                        </select>
                    </span>
                </div>

                <div className={styles.flexing}>
                    <span>
                        <p className={styles.leftPadding}>Type<span className={styles.asterisk}>*</span></p>
                        <select className={styles.tps}
                            name="type"
                            value={issues.typeId}
                            onChange={typeHandler}
                            required
                        >
                            <option value="select" selected disabled>select</option>
                            {types.map((item: {
                                id: number,
                                tType: string
                            }) => <option value={item.id} >{item.tType}</option>
                            )}
                        </select>
                    </span>

                    <span>
                        <p className={styles.leftPadding}>Priority<span className={styles.asterisk}>*</span></p>
                        <select className={styles.tps}
                            name="priority"
                            value={issues.priorityId}
                            onChange={priorityHandler}
                            required
                        >
                            <option value="select" selected disabled>select</option>
                            {priority.map((item: {
                                id: number,
                                PType: string
                            }) => <option value={item.id} >{item.PType}</option>)}
                        </select>
                    </span>

                    <span>
                        <p className={styles.leftPadding}>Story Points<span className={styles.asterisk}>*</span></p>
                        <input className={styles.tps}
                            name="story_points"
                            type='number'
                            // onChange={pointsHandler}
                            placeholder="Points"
                            value={8}
                            required>
                        </input>
                    </span>
                </div>

                <div className={`${styles.dateWrapper} ${styles.flexing}`}>

                    <div className={`${styles.dateStart} ${styles.leftPadding}`}>
                        <label className={styles.labels}>Start Date</label>
                        <input className={styles.startdate} type='date' id='startDateInput' onChange={startdateHandler} value={issues.start_date}></input>
                    </div>
                    <div className={`${styles.dateEnd} ${styles.leftPadding}`}>
                        <label className={styles.labels}>End Date</label>
                        <input className={styles.enddate} type='date' id='endDateInput' onChange={enddateHandler} value={issues.end_date}></input>
                    </div>

                </div>
                <div className={styles.flexing}>
                    <button className={`${styles.btn} ${styles.reset}`} type="reset" onClick={resetHandler}>Reset</button>
                    <button className={`${styles.btn} ${styles.submit}`} type='submit' onClick={submitHandler}>Submit</button>
                </div>
            </Form>
        </div>
    )
}


export default IssueFormComponent;