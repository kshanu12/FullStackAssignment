import React, { useEffect, useState } from "react";
import { Button, Modal, Result } from "antd";

function ModalComponent(props: {
  status: boolean;
  message: string;
}) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  useEffect(()=>{
    showModal()
  },[])
  return (
    <>
      <Button type="primary" onClick={showModal}>
        Open Modal
      </Button>
      <Modal
        title=""
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <Result
          status={props.status? "success":"error"} 
          title={props.message}
        />
      </Modal>
    </>
  );
}

export default ModalComponent;