import React from 'react';
import { Button, Empty } from 'antd';

export default function NoDataImage(props:{message:string}) {
    return (
        <>
            <div style={{ padding: "2rem" }}>
                <Empty
                    image="/images/NoDataImage.png"
                    imageStyle={{ height: "100%", width: "100%" }}
                    description={
                        <span style={{ fontSize: "1.5rem" }}>
                            {props.message}
                        </span>
                    }
                >
                </Empty>
            </div>
        </>
    )
}