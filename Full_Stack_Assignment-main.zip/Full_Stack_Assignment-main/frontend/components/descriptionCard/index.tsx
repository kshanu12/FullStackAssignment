import { Card } from 'antd'
import React from 'react'
import StatusProject from '../statusBarProject'
import Link from 'next/link'

export default function DescriptionCard(props: { path:string,PageId: string, epicId: number, title: string, description: string }) {
   
    return (
        <>
            <div style={{ padding: "0.5rem" }}>
                <Card style={{ width: "100%" }}>
                    <Link href={`/${props.path}`}>
                        <h1>{props.PageId} - {props.title}</h1>
                        <p>{props.description}</p>
                        <StatusProject></StatusProject>
                    </Link>
                </Card>

            </div>
        </>
    )
}
