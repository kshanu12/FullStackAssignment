import React, { Component } from 'react';
import { LaptopOutlined, NotificationOutlined, UserOutlined } from '@ant-design/icons';
import { MenuProps, Space } from 'antd';
import { Breadcrumb, Layout, Menu, theme } from 'antd';
import MenuItem from 'antd/es/menu/MenuItem';
// import { Header } from 'antd/es/layout/layout';
import {
    DesktopOutlined,
    FileOutlined,
    PieChartOutlined,
    TeamOutlined,
} from '@ant-design/icons';
import router from 'next/router';
const { Content, Sider, Header } = Layout;
// const items1: MenuProps['items'] = ['1'].map((key) => ({
//     key,
//     label: `HU PROJECT TRACKER`,
// }));

type MenuItem = Required<MenuProps>['items'][number];

function getItem(
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    children?: MenuItem[],
): MenuItem {
    return {
        key,
        icon,
        children,
        label,
    } as MenuItem;
}
function handleMenuClick(item: MenuItem) {
    // Do something with the clicked item, such as navigating to a new page
    // For example, you can use Next.js's router to navigate to the item's URL:
    router.push(item?.key as string);
}

const items1: MenuItem[] = [
    getItem('Dashboard', '/dashboard', <PieChartOutlined />),
    getItem('Project', ' /project', <DesktopOutlined />),
    getItem('Backlog', '/backlog', <UserOutlined />),
];

function Sidebar() {
    return (
        <>
            <Sider width={200} style={{ background: 'white ' }}>
                <Menu
                    mode="inline"
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    style={{ height: '100%', borderRight: 0 }}
                    items={items1} onClick={handleMenuClick}
                />
            </Sider>
        </>
    )
}
export default Sidebar;