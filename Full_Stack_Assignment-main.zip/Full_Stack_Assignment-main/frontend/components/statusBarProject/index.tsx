import { Progress, Space, Tooltip } from "antd";
import React from "react";

export default function StatusProject() {
    return (
        <>
            <div>
                <Tooltip title="7 done / 2 in progress / 8 to do">
                    <Progress percent={60} success={{ percent: 30 }}  />
                </Tooltip>
            </div>
        </>
    )
}