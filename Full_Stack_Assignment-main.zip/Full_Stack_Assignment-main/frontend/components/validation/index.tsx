import cookie from 'cookie';
import jwtDecode, { JwtPayload } from 'jwt-decode';


export  function getSessionToken() {
  const cookies = cookie.parse(document.cookie);

  return cookies.sessionToken;
}





export  function validateSessionToken(sessionToken: string) {
  try {
    // Decode the JWT token to get the expiration time
    const { exp } = jwtDecode(sessionToken) as JwtPayload;

    // Check if the token has expired
    const now = Date.now() / 1000;
    if(exp)
        return now < exp;
    else  
        return false;
  } catch (error) {
    // If there is an error decoding the token, assume it is invalid
    return false;
  }
}

// export function validateSessionToken(sessionToken) {
//   try {
//     // Decode the JWT token to get the expiration time
//     const { exp } = jwtDecode(sessionToken);

//     // Check if the token has expired
//     const now = Date.now() / 1000;
//     return now < exp;
//   } catch (error) {
//     // If there is an error decoding the token, assume it is invalid
//     return false;
//   }
// }
