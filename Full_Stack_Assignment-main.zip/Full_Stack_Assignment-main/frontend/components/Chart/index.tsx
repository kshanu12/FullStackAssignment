import axios from 'axios';
import styles from './chart.module.css'
import {
    Chart as ChartJs,
    ArcElement,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement
} from 'chart.js'
import React, { useEffect, useState } from 'react';

import { Line } from "react-chartjs-2";
import { Pie } from "react-chartjs-2";
import { errorToast, successToast } from '../Notification';
ChartJs.register(
    LineElement,
    ArcElement,
    CategoryScale,
    LinearScale,
    PointElement,
    Tooltip,
    Legend,
)
// state mamanement

const ChartGraph = () => {


    const [issues, setIssues] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    useEffect(() => {
        setIsLoading(true);
        axios.get('http://localhost:3002/issue/allIssue')
            .then((response) => {
                if (response.status === 200) {
                    setIssues(response.data);
                    // successToast("Issues Found")
                } else if (response.status === 201) {
                    // console.log(response);
                    errorToast("Issues Not Found");
                }
                setIsLoading(false);
            })
            .catch((error) => {
                setIsLoading(false);
            });
    }, []);
    // console.log(issues.data[0])



    // function getDateWiseCount(data) {
    //     const count = {};
    //     const date = data.start_date.slice(0, 10);

    //     if (!count[date]) {
    //         count[date] = {};
    //     }

    //     if (!count[date][data.statusId]) {
    //         count[date][data.statusId] = 0;
    //     }

    //     count[date][data.statusId]++;

    //     return count;
    // }



    // function getDateWiseCount(data: JSON) {
    //     let counts:any = [];
    //     let dates:any = [];
    //     let statusIds:any = [];

    //     const date = data.start_date.slice(0, 10);
    //     const statusId = data.statusId;

    //     let found = false;
    //     counts.forEach(count => {
    //         if (count.date === date && count.statusId === statusId) {
    //             count.count++;
    //             found = true;
    //         }
    //     });

    //     if (!found) {
    //         counts.push({ date, statusId, count: 1 });
    //     }

    //     counts.forEach(count => {
    //         dates.push(count.date);
    //         statusIds.push(count.statusId);
    //     });

    //     return { dates, statusIds, counts: counts.map(count => count.count) };
    // }



    const priority = ["LOW", "MEDIUM", "HIGH"]
    const status = ["TODO", "COMPLETED", "INPROGRESS", "BLOCKED"]
    const type = ["Subtask", "Task", "Defect", "UserStory"]
    let count_todo = 0, count_complete = 0, count_inprogress = 0, count_blocked = 0;



    const date_count = {}

    if (issues) {

        // issues ? issues.map((ise) => {
        //     console.log(getDateWiseCount(ise))
        // }) : []

        let co = 0;
        // console.log(issues)
        const issue_data = issues.response

        issue_data ? issue_data.map((ise) => {
            if (ise.statusId == 1) {
                count_todo++;
            }
            else if (ise.statusId == 2) {
                count_complete++;
            }
            else if (ise.statusId == 3) {
                count_inprogress++;
            }
            else if (ise.statusId == 4) {
                count_blocked++;
            }
            // console.log(ise);
            // let get_data = getDateWiseCount(ise)
            // console.log("co ", co++, get_data)

        }) : []
    }
    // console.log("count_todo ", count_todo)
    // console.log("count_complete ", count_complete)
    // console.log("count_inprogress ", count_inprogress)
    // console.log("count_blocked ", count_blocked)



    const date = ['14 Apr', '15 Apr', '16 Apr', '17 Apr', "18 Apr", "19 Apr", "20 Apr"] //change it by 7 date


    const log = [
        { date: '2022-01-01', todo: 5, completed: 2, inProgress: 1, blocked: 0 },
        { date: '2022-01-02', todo: 8, completed: 3, inProgress: 6, blocked: 1 },
        { date: '2022-01-03', todo: 10, completed: 5, inProgress: 3, blocked: 2 },
        { date: '2022-01-03', todo: 3, completed: 6, inProgress: 1, blocked: 2 },
        { date: '2022-01-03', todo: 7, completed: 4, inProgress: 3, blocked: 12 },
        { date: '2022-01-03', todo: 10, completed: 9, inProgress: 14, blocked: 2 },
        { date: '2022-01-03', todo: 6, completed: 8, inProgress: 3, blocked: 8 },
        // Add more data as needed
    ];

    const lineChart: any = {
        labels: date,
        datasets: [
            {
                label: 'Todo',
                data: log.map((d) => d.todo), // Extracting the count of todo status
                backgroundColor: '#1890FF',
                borderColor: '#1890FF',
                fill: false,
            },
            {
                label: 'Done',
                data: log.map((d) => d.completed), // Extracting the count of completed status
                backgroundColor: '#52C41A',
                borderColor: '#52C41A',
                fill: false,
            },
            {
                label: 'In Progress',
                data: log.map((d) => d.inProgress), // Extracting the count of inProgress status
                backgroundColor: '#FFA940',
                borderColor: '#FFA940',
                fill: false,
            },
            {
                label: 'Blocked',
                data: log.map((d) => d.blocked), // Extracting the count of blocked status
                backgroundColor: '#F5222D',
                borderColor: '#F5222D',
                fill: false,
            },
        ],
    }

    const lineoptions = {
        plugins: {
            legend: true
        },
        scales: {
            y: {
                min: 0,
                max: 20,
                stepSize: 5
            }
        }
    }

    const pieChart: any = {
        labels: ['To Do', 'In Progress', 'Blocked', 'Done'],
        datasets: [
            {
                data: [count_todo, count_inprogress, count_blocked, count_complete],
                backgroundColor: ['#1890FF', '#FFA940', '#F5222D', '#52C41A'],
                borderColor: ['white', 'white', 'white', 'white']
            },
            {
                data: [3],
                backgroundColor: ['white']
            }
        ]
    }

    const pieoptions = {
        plugins: {
            legend: {
                position: 'right' // show the legend at the bottom of the chart
            }
        },
    }

    return (
        <>
            <div className={styles.chart}>
                <div className={styles.line}>
                    <Line
                        data={lineChart}
                        options={lineoptions}
                    ></Line>
                </div >
                <span className={styles.verticle_line}></span>
                <div className={styles.pie}>
                    <Pie
                        data={pieChart}
                        options={pieoptions}
                    ></Pie>
                </div>
            </div>
        </>
    )
}

export default ChartGraph

// import styles from './chart.module.css'
// import {
//     Chart as ChartJs,
//     ArcElement,
//     Tooltip,
//     Legend,
//     LineElement,
//     CategoryScale,
//     LinearScale,
//     PointElement
// } from 'chart.js'
// import React, { useState, useEffect } from 'react';

// import { Line } from "react-chartjs-2";
// import { Pie } from "react-chartjs-2";
// ChartJs.register(
//     LineElement,
//     ArcElement,
//     CategoryScale,
//     LinearScale,
//     PointElement,
//     Tooltip,
//     Legend,
// )

// const ChartGraph = () => {

//     const date = ['Mon', 'Tue', 'Wed', 'abc', "xyz", "efg", "tuv"]
//     const priority=["LOW","MEDIUM","HIGH"]
//     const status=["TODO","COMPLETED","InProgress","BLOCKED"]

//     const [log, setLog] = useState([]);

//     useEffect(() => {
//         fetch("http://localhost:3002/issue/allIssue")
//             .then(response => response.json())
//             .then(data => {
//                 setLog(data);
//             });
//     }, []);

//     const lineChart: any = {
//         labels: date,
//         datasets: [
//             {
//                 label: 'Todo',
//                 data: log.map((d) => d.todoCount),
//                 backgroundColor: '#1890FF',
//                 borderColor: '#1890FF',
//                 fill: false,
//             },
//             {
//                 label: 'Done',
//                 data: log.map((d) => d.completedCount),
//                 backgroundColor: '#52C41A',
//                 borderColor: '#52C41A',
//                 fill: false,
//             },
//             {
//                 label: 'In Progress',
//                 data: log.map((d) => d.inProgressCount),
//                 backgroundColor: '#FFA940',
//                 borderColor: '#FFA940',
//                 fill: false,
//             },
//             {
//                 label: 'Blocked',
//                 data: log.map((d) => d.blockedCount),
//                 backgroundColor: '#F5222D',
//                 borderColor: '#F5222D',
//                 fill: false,
//             },
//         ],
//     }

//     const lineoptions = {
//         plugins: {
//             legend: true
//         },
//         scales: {
//             y: {
//                 min: 0,
//                 max: 20,
//                 stepSize: 5
//             }
//         }
//     }

//     const pieChart: any = {
//         labels: ['To Do', 'In Progress', 'Blocked', 'Done'],
//         datasets: [
//             {
//                 data: [log.reduce((sum, { todoCount }) => sum + todoCount, 0),
//                        log.reduce((sum, { inProgressCount }) => sum + inProgressCount, 0),
//                        log.reduce((sum, { blockedCount }) => sum + blockedCount, 0),
//                        log.reduce((sum, { completedCount }) => sum + completedCount, 0)],
//                 backgroundColor: ['#1890FF', '#FFA940', '#F5222D', '#52C41A'],
//                 borderColor: ['white', 'white', 'white', 'white']
//             },
//             {
//                 data: [3],
//                 backgroundColor: ['white']
//             }
//         ]
//     }

//     const pieoptions = {
//         plugins: {
//             legend: {

