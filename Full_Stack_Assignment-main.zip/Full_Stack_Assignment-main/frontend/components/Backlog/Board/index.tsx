import React, { useEffect, useState } from "react";
import StatusBoard from "../StatusBoard";
import axios from "axios";
import styles from "./board.module.css";
import Filter from "../Filter";
import { updateDataStatus } from "../../../method/issue";
import { getDataStatus } from "@/method/status";

type status = {
  Id: number;
  status: string;
};

type statusType = {
  id: number;
  title: string;
};

// const getDataStatus = async () => {
//     try {
//         const response = await axios.get('http://localhost:3002/status');
//         console.log("response", response.data.response);

//         return response.data.response;
//     } catch (error) {
//         console.error(error);
//     }
// }

// const updateDataStatus = async (id: number, updatedStatusId: number) => {
//     try {
//         const response = await axios.patch(`http://localhost:3002/issue/${id}`, { statusId: updatedStatusId });
//         console.log("response", response.data.response);

//         return response.data.response;
//     } catch (error) {
//         console.error(error);
//     }
// }

const Board = () => {
  const [status, setStatus] = useState<statusType[]>([]);
  const [toggleStatus, setToggleStatus] = useState(false);
  const [selectedType, setSelectedType] = useState(0);
  const [selectedPriority, setSelectedPriority] = useState(0);
  const [selestedAssignee, setSelectedAssignee] = useState(0);
  const [selectedProject, setSelectedProject] = useState(0);

  const fetchData = async () => {
    const res = await getDataStatus();
    // console.warn(res)

    let statusNames = [];
    console.log("res", res);

    statusNames = res.map((statusName: status) => {
      return {
        id: statusName.Id,
        title: statusName.status,
      };
    });
    setStatus(statusNames);
    console.log("status Name", statusNames);
  };

  //function ghandling the things when we selecet from mouse
  const onDragStart = (
    event: React.DragEvent<HTMLDivElement>,
    taskId: string
  ) => {
    console.log("dragstart on div: ", taskId);
    event.dataTransfer.setData("taskId", taskId);
  };

  //notify the things when we hiver on it
  const onDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };

  const onDrop = async (
    event: React.DragEvent<HTMLDivElement>,
    status: statusType
  ) => {
    let taskId = event.dataTransfer.getData("taskId");
    console.log("dragstop on div: ", taskId, status.title);
    const result = updateDataStatus(Number(taskId), status.id);

    // console.log("result", result)

    fetchData();
    setToggleStatus(!toggleStatus);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <Filter
        selectedType={selectedType}
        setSelectedType={setSelectedType}
        selectedPriority={selectedPriority}
        setSelectedPriority={setSelectedPriority}
        selectedAssignee={selestedAssignee}
        setSelectedAssignee={setSelectedAssignee}
      ></Filter>
      <div className={styles.board}>
        <div className={styles.content}>
          {status.map((stat) => (
            <div
              className={styles.elements}
              onDragOver={(event) => onDragOver(event)}
              onDrop={(event) => {
                onDrop(event, stat);
              }}
            >
              <StatusBoard
                toggleStatus={toggleStatus}
                status={stat}
                onDragStart={onDragStart}
                selectedType={selectedType}
                selectedPriority={selectedPriority}
                selectedAssignee={selestedAssignee}
                selectedProject={selectedProject}
              />
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Board;
