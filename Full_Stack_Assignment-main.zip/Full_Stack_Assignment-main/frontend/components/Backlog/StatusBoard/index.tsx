import React, {
  Dispatch,
  SetStateAction,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import Task from "../Task";
import styles from "./statusBoard.module.css";
import axios from "axios";
import { getProjectDataById } from "@/method/project";

type statusType = {
  id: number;
  title: string;
};

type prop = {
  status: statusType;
  onDragStart: (event: React.DragEvent<HTMLDivElement>, taskId: string) => void;
  toggleStatus: boolean;
  selectedType: number;
  selectedPriority: number;
  selectedAssignee: number;
  selectedProject: number;
};

type issue = {
  Id: string;
  title: string;
  description: string;
  assigneeId: number;
  reporterId: number;
  typeId: number;
  statusId: number;
  priorityId: number;
  start_date: Date;
  end_date: Date;
  epicId: number;
};

interface MyObject {
  statusId: number;
  [key: string]: any;
}

const StatusBoard = (props: prop) => {
  const [issues, setIssues] = useState<issue[]>([]);
  // console.warn("Rendering again")
  // console.warn(props.status)

  let reqBody: MyObject = { statusId: props.status.id };
  if (props.selectedProject !== undefined && props.selectedProject !== 0) {
  } else {
    if (props.selectedType !== undefined && props.selectedType !== 0) {
      reqBody["typeId"] = props.selectedType;
    }
    if (props.selectedPriority !== undefined && props.selectedPriority !== 0) {
      reqBody["priorityId"] = props.selectedPriority;
    }
    if (props.selectedAssignee !== undefined && props.selectedAssignee !== 0) {
      reqBody["assigneeId"] = props.selectedAssignee;
    }
  }

  console.log("-----------------------", reqBody);

  const createPost = async () => {
    await axios
      .post("http://localhost:3002/issue/filter", reqBody)
      .then((response) => {
        // console.log("response", response.data.res);
        setIssues(response.data.res);
      });
  };

  useEffect(() => {
    // console.log("props", props.status.id);
    // console.warn("Calling fetch data again")
    if (props.selectedProject !== undefined && props.selectedProject !== 0) {
      getProjectDataById(props.selectedProject);
    } else {
      createPost();
    }
  }, [
    props.toggleStatus,
    props.selectedType,
    props.selectedPriority,
    props.selectedAssignee,
  ]);

  console.log(
    "==================================",
    props,
    "======================================="
  );

  return (
    <div className={styles.board}>
      <div className={styles.statusBoard}>
        <div className={styles.statusBoardHead}>{props.status.title}</div>
        {issues?.map((issue) => (
          <div
            draggable
            onDragStart={(event) => props.onDragStart(event, issue.Id)}
          >
            <Task data={issue} status={props.status.title} key={issue.Id} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default StatusBoard;
