import React, { useState } from 'react'
import styles from './task.module.css'

type prop = {
    data: {
        Id: string,
        title: string,
        description: string,
        assigneeId: number,
        reporterId: number,
        typeId: number,
        statusId: number,
        priorityId: number,
        start_date: Date,
        end_date: Date,
        epicId: number
    },
    status: string
}

const Task = (props: prop) => {

    return (
        // single card 
        <div className={styles.task}>
            <div className={styles.taskTitle}>
                {props.data.title}
            </div>
            <div className={styles.taskDesc}>
                {props.data.description}
            </div>
            <div className={styles.taskAssignee}>
                <div className={styles.taskAssigneeCircle}>
                    {props.data.assigneeId}
                </div>
            </div>
        </div>
    )
}

export default Task