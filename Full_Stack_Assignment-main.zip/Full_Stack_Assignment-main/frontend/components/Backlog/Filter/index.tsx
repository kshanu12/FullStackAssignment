import { Select, Space } from "antd";
import styles from "./filter.module.css";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { getDataTypes } from "@/method/types";
import { getDataPriority } from "@/method/priority";
import { users } from "@/components/IssueForm";
import { getUsersData } from "@/method/users";

type types = {
  Id: number;
  tType: string;
};

type priority = {
  Id: number;
  PType: string;
};

type prop = {
  selectedType: number;
  selectedPriority: number;
  setSelectedType: React.Dispatch<React.SetStateAction<number>>;
  setSelectedPriority: React.Dispatch<React.SetStateAction<number>>;
  selectedAssignee: number;
  setSelectedAssignee: React.Dispatch<React.SetStateAction<number>>;
};

const Filter = (props: prop) => {
  console.log("this is props: ", props);

  const projects = [
    "select",
    "Meeting with John",
    "Lunch with colleagues",
    "Family vacation",
    "Training session",
    "Birthday party",
  ];
  const data = ["select", "Fix the bug", "Hands On", "Assignmnet", "Feedback"];

  const [types, setTypes] = useState([]);
  const [priority, setPriority] = useState([]);
  const [users, setUsers] = useState<users[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const res = await getDataTypes();
      let typesNames = [];
      typesNames = res.map((typeName: types) => {
        return {
          Id: typeName.Id,
          tType: typeName.tType,
        };
      });
      setTypes(typesNames);
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      const res = await getDataPriority();
      let typesNames = [];
      typesNames = res.map((typeName: priority) => {
        return {
          Id: typeName.Id,
          PType: typeName.PType,
        };
      });
      setPriority(typesNames);
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      const res = await getUsersData();
      // console.log("-------------------", res);

      let users = [];
      users = res.map((user: users) => {
        return {
          Id: user.Id,
          first_name: user.first_name,
          last_name: user.last_name,
          role: user.role,
          email: user.email,
          password: user.password,
          teamId: user.teamId,
        };
      });
      setUsers(users);
    };
    fetchData();
  }, []);
  // console.log("users", users);

  return (
    <>
      <div className={styles.filterBody}>
        <h2>FILTERS</h2>
        <Space wrap className={styles.filterBodyContents}>
          {/* <div>
            <div className={styles.title}>Project</div>
            <Select
              defaultValue={projects[0]}
              style={{ width: 400 }}
              // onChange={handleProvinceChange}
              options={projects.map((project) => ({
                label: project,
                value: project,
              }))}
            />
          </div> */}
          {/* <div>
            <div className={styles.title}>Epic</div>
            <Select
              defaultValue={data[0]}
              style={{ width: 400 }}
              // onChange={handleProvinceChange}
              options={data.map((item) => ({ label: item, value: item }))}
            />
          </div> */}
          <div>
            <div className={styles.title}>Assignee</div>
            <select
              className={styles.elements}
              name="assignee"
              value={props.selectedAssignee}
              onChange={(e) =>
                props.setSelectedAssignee(Number(e.target.value))
              }
              required
            >
              <option value="0" selected disabled>
                select
              </option>
              {users.map((user: users) => (
                <option
                  value={user.Id}
                >{`${user.first_name} ${user.last_name}`}</option>
              ))}
            </select>
          </div>
          <div>
            <div className={styles.title}>Priority</div>
            <select
              className={styles.elements}
              name="priority"
              value={props.selectedPriority}
              onChange={(e) =>
                props.setSelectedPriority(Number(e.target.value))
              }
              required
            >
              <option value="0" selected disabled>
                select
              </option>
              {priority.map((user: priority) => (
                <option value={user.Id}>{user.PType}</option>
              ))}
            </select>
          </div>
          <div>
            <div className={styles.title}>Type</div>
            <select
              className={styles.elements}
              name="type"
              value={props.selectedType}
              onChange={(e) => props.setSelectedType(Number(e.target.value))}
              required
            >
              <option value="0" selected disabled>
                select
              </option>
              {types.map((user: types) => (
                <option value={user.Id}>{user.tType}</option>
              ))}
            </select>
          </div>
        </Space>
      </div>
    </>
  );
};

export default Filter;
