import Link from "next/link";
import styles from "./Index.module.css";
import Image from "next/image";
import React, { ReactNode, useState } from "react";
import axios from "axios";
import { useRouter } from "next/router";
import { Button, Checkbox, Form, Input } from "antd";

import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";

// export type User = {
//   email: string;
//   password: number;
// }

// interface Props {
//   user?: User[]
// }

// export const getServerSideProps = async () => {
//   const url="http://localhost:3002/employee"
//   // const url = "https://swapi.dev/api/people/1/";
//   const res = await axios.get(url).then((data: any) => (data)).catch((error: Error) => (error))
//   // console.log(res.data)
//   const temp = res.data.getData
//   return {
//     props: { user: temp}
//   }

// }

// import showNotification from "./notification";

// import Cookies from 'js-cookie';
import Cookies from "js-cookie";
import { errorToast, successToast } from "../Notification";

type LoginPageProps = {
  children: ReactNode;
};

export default function LoginPage(props: LoginPageProps) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    axios
      .post("http://localhost:3002/login", { email, password })
      .then((response) => {
        if (response.status === 200) {
          sessionStorage.setItem("user", JSON.stringify(response.data));
          Cookies.set("user", response.data);
          setIsLoading(false);

          successToast("User Is Logged In");
          router.push("/dashboard");
        } else if (response.status === 201) {
          // console.log(response)
          errorToast("Email Id or password is not valid");
          router.push("/login");
        }
      })
      .catch((error) => {
        setIsLoading(false);
        errorToast("Error has been encountered ");
        // showNotification('error', 'Logging Failed')
      });
  };

  const pageChange = () => {
    router.push("/login/changepassword");
  };

  return (
    <div className={styles.container}>
      <div className={styles.huProjectTracker}>HU Project Tracker</div>
      <div className={styles.loginImage}>
        <Image
          src="/images/login.png"
          alt="Picture of the author"
          width={380}
          height={277}
        />
      </div>
      <div className={styles.loginCard}>
        <form onSubmit={handleSubmit} method="post">
          <label htmlFor="email" className={styles.username}>
            Email <span className={styles.astrik}>*</span>
          </label>
          <input
            className={styles.usernamePlaceHolder}
            type="email"
            id="email"
            name="email"
            placeholder="UserName@deloitte.com"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <div className={styles.firstline}></div>

          <label htmlFor="password" className={styles.password}>
            Password <span className={styles.astrik}>*</span>
          </label>
          <input
            className={styles.passwordPlaceHolder}
            type="password"
            id="password"
            name="password"
            placeholder="******"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div className={styles.secondline}></div>

          <button className={styles.reset} type="reset">
            Reset
          </button>
          <button className={styles.confirm} type="submit">
            Confirm
          </button>
        </form>
        <Link className={styles.changePassword} onClick={pageChange} href={""}>
          <h4>Click here to change password.</h4>
        </Link>
      </div>

      <div className={styles.eclipse}>
        <Image
          className={styles.vector}
          src="/images/vector.png"
          alt="Picture of the author"
          width={80}
          height={80}
        />
      </div>
    </div>
  );
}
