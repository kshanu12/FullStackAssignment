import { toast } from "react-toastify";

export const errorToast = (errorMsg: string) => {
    toast.error(errorMsg, {
        toastId: "errorToast",
        position: "bottom-left",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
    });
}


export const successToast = (successMsg: string) => {
    toast.success(successMsg, {
        toastId: "successToast",
        position: "bottom-left",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
    });
}



export const pendingToast = (pendingMsg: string) => {
    toast.info(pendingMsg, {
        toastId: "pendingToast",
        position: "bottom-left",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
    });
}