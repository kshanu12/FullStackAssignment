import React, { useEffect, useState } from "react";
import { Button, Space, Spin, Table, Tag } from "antd";
import task from "./icons/task.png";
import subTask from "./icons/subTask.png";
import userStory from "./icons/userStory.png";
import defect from "./icons/defect.png";
import low from "./icons/low.png";
import medium from "./icons/equal.png";
// import high from "./icons/high.png"
import high from './icons/high.png'
import Image from "next/image";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { errorToast, successToast } from "../Notification";
import router from "next/router";
import axios from "axios";
import Cookies from "js-cookie";
import { deleteDataForAssigneeId, getListOfDataFilterAssigneeeId, getListOfDataFiltere_Idandp_Id } from "../../method/cardlist";
import { getUserBySessionKey } from "../../method/sessionkey";


import { Pagination } from "antd";
import MasterCard from "../masterCard";






// const priority = ["LOW", "MEDIUM", "HIGH"]
// const status = ["TODO", "COMPLETED", "INPROGRESS", "BLOCKED"]
// const type = ["Subtask", "Task", "Defect", "UserStory"]



function getTypeImg(id: number) {
  if (id == 1) return <Image src={subTask} alt="Subtask" />;
  else if (id == 2) return <Image src={task} alt="Task" />;
  else if (id == 3) return <Image src={defect} alt="Defect" />;
  else if (id == 4) return <Image src={userStory} alt="UserStory" />;
  else return undefined;
}

function getPriorityImg(id: number) {
  // console.log(id)
  if (id == 1) return <Image src={low} alt="low" />;
  else if (id == 2) return <Image src={medium} alt="medium" />;
  else if (id == 3) return <Image src={high} alt="high" />;
  else return undefined;
}

function getStatus(id: number, code: number) {
  if (id == 1) return code == 1 ? "blue" : "TO DO";
  else if (id == 3) return code == 1 ? "yellow" : "IN PROGRESS";
  else if (id == 2) return code == 1 ? "green" : "DONE";
  else if (id == 4) return code == 1 ? "red" : "BLOCKED ";
}


function CardListEpic(props:{projectId:number,epicId:number}) {

  const [data, setData] = useState<any>();
  const [page, setPage] = useState<number>(1);
  const [beforeDelete, updateDelete] = useState<any>()


  // console.log(process.env.BASE_URL)
  const handledelete = async (id: number) => {

    const resp = await deleteDataForAssigneeId(9);
    if (resp.data.status == 200) {
      updateDelete(resp.data)
      // console.log("deleted data: ", resp)
    } else {
      errorToast("Data Id is Not Valid or Not Found")
    }
  }


  const userDeatails: any = getUserBySessionKey();
  useEffect(() => {
    if (userDeatails) {
      const getSession = async () => {
        const asigneeId = userDeatails.user?.Id;

        if (asigneeId) {
          const result = await getListOfDataFiltere_Idandp_Id(asigneeId,props.epicId)
          // console.log(result, "sidwughr3nf")
          if (result.data.message == "Sucess") {
            setData(result.data)
            // console.log("result", result)
          }
        }
      };

      getSession();
    }

  }, [userDeatails])

  // console.log(data)


  let all_data;
  let dataSource1 = []

  if (data) {
    all_data = data.res;


    const start = (page - 1) * 3;
    const end = page * 4;
    const sliced_data = all_data.slice(start, end);

    dataSource1 = all_data.map((each_data) => {
      return {
        key: each_data.Id.toString(),
        priority: getPriorityImg(each_data.priorityId),
        type: getTypeImg(each_data.typeId),
        taskId: (each_data.Id),
        taskTitle: each_data.title,
        status: Number(each_data.statusId),
        buttons: (
          <div>
            <Button>
              <EditOutlined />{" "}
            </Button>{" "}
            <Button onClick={() => handledelete(each_data.Id)}>
              <DeleteOutlined />
            </Button>{""}
          </div>
        ),
      };
    });

  }


  const columns = [
    {
      title: "Priority",
      dataIndex: "priority",
      key: "priority",
    },
    {
      title: "Type",
      dataIndex: "type",
      key: "type",
    },
    {
      title: "Task ID",
      dataIndex: "taskId",
      key: "taskId",
    },
    {
      title: "Task Title",
      dataIndex: "taskTitle",
      key: "taskTitle",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (_, props) => (
        <>
          {
            <Tag color={getStatus(props.status, 1)} key={props.status}>
              {getStatus(props.status, 0)}
            </Tag>
          }
        </>
      ),
    },
    {
      title: "",
      dataIndex: "buttons",
      key: "buttons",
    },
  ];


  return (
    <>
      {/* {console.log("data", data)} */}
      <Table dataSource={dataSource1} columns={columns} />
      <div >
        {/* <Space >
          <Button style={{ alignItems: 'flex-start' }} type="primary" onClick={() => setPage(page === 1 ? 1 : page - 1)}>prev</Button>
          <Button style={{ alignItems: 'flex-end' }} type="primary" onClick={() => setPage(page === 3 ? 3 : page + 1)}>next</Button>
        </Space> */}
      </div>
    </>
  );
}

export default CardListEpic;