import { Button } from "antd";
import axios from "axios";
import React from "react";
import { errorToast, successToast } from "../Notification";
import { useRouter } from "next/router";
import Cookies from 'js-cookie';

function Logout() {
    const router = useRouter();
    const handleLogout = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.get('http://localhost:3002/logout');
            // if(response)

            if (response.data.status) {
                sessionStorage.clear();
                // Remove the 'user' cookie
                Cookies.remove('user');

                // Remove the 'user' data from sessionStorage
                sessionStorage.removeItem('user');

                document.cookie.split(';').forEach(cookie => {
                    const name = cookie.split('=')[0];
                    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                });
                router.push("/")
                successToast("Logged Out Sucessfully")
            } else {
                successToast("User Not LoggedIn")
            }
        } catch (error) {
            errorToast("Error Found")
            // console.log("Error")
        }
    }

    return (
        <>
            <Button style={{ float: "right" }} onClick={handleLogout}> Logout</Button>
        </>
    )
}
export default Logout;