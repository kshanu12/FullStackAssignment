import React, { Component } from 'react';
import { LaptopOutlined, NotificationOutlined, UserOutlined } from '@ant-design/icons';
import { Badge, Image, MenuProps, Space } from 'antd';
import { Breadcrumb, Layout, Menu, theme } from 'antd';
import MenuItem from 'antd/es/menu/MenuItem';
// import { Header } from 'antd/es/layout/layout';
import {
    DesktopOutlined,
    FileOutlined,
    PieChartOutlined,
    TeamOutlined,
} from '@ant-design/icons';
import router from 'next/router';
import Logout from '../logout';
const { Content, Sider, Header } = Layout;

type MenuItem = Required<MenuProps>['items'][number];

function getItem(
    label: React.ReactNode,
    key: React.Key,
    icon?: React.ReactNode,
    children?: MenuItem[],
): MenuItem {
    return {
        key,
        icon,
        children,
        label,
    } as MenuItem;
}
function handleMenuClick(item: MenuItem) {
    // Do something with the clicked item, such as navigating to a new page
    // For example, you can use Next.js's router to navigate to the item's URL:
    router.push(item?.key as string);
}

const items1: MenuItem[] = [
    getItem('Dashboard', '/dashboard', <PieChartOutlined />),
    getItem('Project', ' /project', <DesktopOutlined />),
    getItem('Backlogs', ' /backlogs', <UserOutlined />),
];


const items2: MenuItem[] = [
    getItem('HU PROJECT TRACKER', '/')
];


function Headers() {
    return (
        <div>
            <Header  >

                <Menu theme="dark" mode="horizontal" items={items2} onClick={handleMenuClick} >

                </Menu>

            </Header>
            <Logout />
            {/* <button style={{ color: "white", float: "right" }}>Logout</button> */}
        </div>
    )
}
export default Headers;
// function Headers() {
//     return (
//         <>
//             <div className="AppHeader">
//                 <Layout >
//                     <Header className="header" style={{ width: "100%", height: "6rem" }} >
//                         <div className="logo" />

//                         <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']} items={items2} onClick={handleMenuClick} />
//                     </Header>

//                     <Layout style={{ height: "76rem", top: "67rem" }}>
//                         <Sider width={200} style={{ width: "20rem", height: "76rem", background: 'white' }}>
//                             <Menu
//                                 mode="inline"
//                                 defaultSelectedKeys={['1']}
//                                 defaultOpenKeys={['sub1']}
//                                 style={{ height: '100%', borderRight: 0, background: '#FFFFFF' }}
//                                 items={items1} onClick={handleMenuClick}
//                             />
//                         </Sider>
//                         <Layout  >

//                             <Content
//                                 style={{
//                                     padding: 24,
//                                     margin: 0,
//                                     minHeight: 280,
//                                     background: 'white',
//                                 }}
//                             >
//                                 {/* <Component {...pageProps} /> */}
//                             </Content>
//                         </Layout>
//                     </Layout>

//                 </Layout>
//             </div>
//         </>
//     )
// }
// export default Headers;
