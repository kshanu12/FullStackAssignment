// import '@/styles/globals.css'
// import type { AppProps } from 'next/app'

// export default function App({ Component, pageProps }: AppProps) {
//   return <Component {...pageProps} />
// }

// import '@/styles/globals.css'
// import type { AppProps } from 'next/app'
// import React from 'react'
// import Headers from '../components/Header'
// export default function App({ Component, pageProps }: AppProps) {
//   return <>
//     <Headers >
//       <Component {...pageProps} />
//     </Headers>
//   </>
// }












import { Image, Typography, Badge } from "antd";

import Headers from '../components/Header';
import React, { useEffect, useState } from 'react';
import { UserOutlined } from '@ant-design/icons';
import { MenuProps, Space } from 'antd';
import { Breadcrumb, Layout, Menu, theme } from 'antd';
import MenuItem from 'antd/es/menu/MenuItem';
import {
  DesktopOutlined,
  PieChartOutlined,

} from '@ant-design/icons';
import router, { useRouter } from 'next/router';
import { AppProps } from 'next/app';
// import Sidebar from '../components/Sidebar/indes';
import LoginPage from "../components/login";
import IssueContainer from "../components/IssueForm";
import { request } from "http";
// import { getSessionToken, validateSessionToken } from "../components/validation";
const { Content, Sider, Header } = Layout;
import Cookies from 'js-cookie';
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer } from "react-toastify";
// import CardList from "../components/CardList";
import ChartGraph from "../components/Chart";
import Logout from "../components/logout";
// import ChangePassword from "./login/changepassword";
import BreadCrumb from "../components/breadcrumbs/breadCrumb";
import Sidebar from "@/components/Sidebar";



export default function App({ Component, pageProps }: AppProps) {


  const [user, setUser] = useState(null);

  // var session=""
  useEffect(() => {
    // Try to get the user data from sessionStorage
    const userString = sessionStorage.getItem('user');
    const userFromSession = userString ? JSON.parse(userString) : null;

    // Try to get the user data from Cookies
    // const userFromCook = Cookies.get('user');
    const userFromCookies = JSON.parse(sessionStorage.getItem('user') ?? 'null');

    // console.log("user ka token",userFromCookies);

    // Use the user data from either sessionStorage or Cookies, if it's valid
    if (userFromSession && userFromSession.user.Id && userFromSession.user.email) {
      // console.log("inside data 1",userFromCookies)
      setUser(userFromSession);
    } else if (userFromCookies && userFromCookies.user.Id && userFromCookies.user.email) {
      // console.log("inside data 2",userFromCookies)
      setUser(userFromCookies);
    }
  }, [Cookies.get('user')]);

  // console.log("session",user);


  if (!user) {
    return (
      <>
        <ToastContainer></ToastContainer>
        <LoginPage children={undefined} />
        {/* <ChangePassword/> */}
        {/* <IssueContainer></IssueContainer> */}
        {/* <CardList/> */}
        {/* <Logout/> */}
      </>
    )
  }
  else {
    return (
      <>
        <ToastContainer></ToastContainer>
        <Layout>

          <Headers />

          <Layout>
            <Sidebar />
            <Layout style={{ padding: '0 24px 24px' }}>
              <BreadCrumb />
              <Component {...pageProps} />
            </Layout>
          </Layout>
        </Layout>

      </>
    )
  }
}