import Board from "@/components/Backlog/Board"

const Backlog = () => {
    return (
        <>
            <h1>Backlog Page</h1>
            <Board></Board>
        </>
    )
}

export default Backlog