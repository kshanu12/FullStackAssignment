import Image from "next/image";
import styles from './changepassword.module.css';
import { useState } from 'react';

import React from 'react';
import resetPassword from '../../../method/changePassword';
import Link from "next/link";
import { errorToast, successToast } from "../../../components/Notification";

const ChangePassword = () => {


  const [email, setEmail] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState({});

  const handleSubmit = async (event) => {
    event.preventDefault();
    // console.log("inside ", email, oldPassword, newPassword, confirmPassword)

    if (Object.keys(errors).length === 0) {
      try {
        // console.log("oinutside ", email, oldPassword, newPassword, confirmPassword)

        const response = await resetPassword(email, oldPassword, newPassword);
        if (response.status === 200) {
          // console.log("data response",response.status)
          successToast("Password has been changed Sucessfully")

        } else {
          errorToast("Password unchanged")
        }
      } catch (error) {
        errorToast("Error")
        setMessage(error.message);
      }
    } else {
      setErrors(errors);
    }
  };
  


  // console.log("reset password")
  return (
    <div>
      <form >
        <div>
          <div className={styles.huProjectTracker}>HU Project Tracker</div>
          <div className={styles.loginImage}>
            <Image
              src="/../public/images/login.png"
              alt="Picture of the author"
              width={380}
              height={277}
            />
          </div>
          <div className={styles.loginCard}>
            <form onClick={handleSubmit} method="put">
              <label htmlFor="first" className={styles.username}>
                Email <span className={styles.astrik}>*</span>
              </label>
              <input
                className={styles.usernamePlaceHolder}
                type="emial"
                id="emial"
                name="email"
                placeholder="UserName@deloitte.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />

              <div className={styles.firstline}></div>

              <label htmlFor="last" className={styles.password}>
                Password <span className={styles.astrik}>*</span>
              </label>
              <input
                className={styles.passwordPlaceHolder}
                type="password"
                id="last"
                name="last"
                placeholder="******"
                required
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
              />

              <div className={styles.secondline}></div>

              <label htmlFor="last" className={styles.newPassword}>
                New Password <span className={styles.astrik}>*</span>
              </label>
              <input
                className={styles.newPasswordPlaceHolder}
                type="password"
                id="newPassword"
                name="newPassword"
                placeholder="******"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />

              <div className={styles.thirdline}></div>

              <label htmlFor="last" className={styles.confirmPassword}>
                Confirm Password <span className={styles.astrik}>*</span>
              </label>
              <input
                className={styles.confirmPasswordPlaceHolder}
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                placeholder="******"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />

              <div className={styles.fourthline}></div>

              <button className={styles.reset} type="submit">
                Reset
              </button>
              <button className={styles.confirm} type="submit">
                Confirm
              </button>
            </form>
            <Link className={styles.login} href={`/`}><h4>Click here to Login.</h4></Link>
          </div>
        </div>
      </form>
    </div>
  );
};

export default ChangePassword;
