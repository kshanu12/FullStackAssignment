import ChartGraph from "@/components/Chart";

const HomePage = () => {
  return (
    <>
      <ChartGraph></ChartGraph>
    </>
  );
};

export default HomePage;
