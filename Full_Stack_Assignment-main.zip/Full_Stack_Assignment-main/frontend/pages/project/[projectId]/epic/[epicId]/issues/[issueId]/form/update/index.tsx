import IssueFormComponent from "@/components/IssueForm"

const IssueFormUpdate = () => {
    return (
        <>
            <div>
                <IssueFormComponent></IssueFormComponent>
            </div>
        </>
    )
}

export default IssueFormUpdate