import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import IssueContainer from "../../../../../components/IssueForm";
import CardList from "../../../../../components/CardList";
import MasterCard from "../../../../../components/masterCard";
import { getEpicDataByEId } from "../../../../../method/deatailsEpic";
import NoDataImage from "../../../../../components/NoData";
import CardListEpic from "../../../../../components/CardListEpic";

export default function EpicId() {
  const router = useRouter();
  // console.log("epic Id:", router)
  const { projectId, epicId } = router.query;
  const pId = Number(projectId);
  const eId = Number(epicId);

  const [data, setData] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [cardsPerPage, setCardsPerPage] = useState(4);

  useEffect(() => {
    async function fetchData() {
      const result = await getEpicDataByEId(eId);
      setData(result);
    }
    fetchData();
  }, []);

  console.log("data inside:", data);

  if (!data) {
    return (
      <NoDataImage
        message={"Data Is Not yet Loaded or Emply Data"}
      ></NoDataImage>
    );
  }

  const final_data = data.data.result;
  // console.log(final_data)

  return (
    <>
      <div>
        <MasterCard
          epicId={eId}
          title={final_data.title}
          description={final_data.description}
        ></MasterCard>

        {/* <p>{projectId }</p>
            <p>{epicId}</p>
            <h1>kjsdkj</h1> */}
        <CardListEpic projectId={pId} epicId={eId}></CardListEpic>
      </div>
    </>
  );
}
