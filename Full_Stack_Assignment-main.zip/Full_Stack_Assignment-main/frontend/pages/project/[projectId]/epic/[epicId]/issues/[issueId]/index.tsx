const IssuesId = () => {
    return (
        <>
            <h1>IssuesId Page</h1>
        </>
    )
}

export default IssuesId