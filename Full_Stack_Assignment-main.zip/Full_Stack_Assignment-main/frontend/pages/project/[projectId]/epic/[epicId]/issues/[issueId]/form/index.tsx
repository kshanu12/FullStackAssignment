const IssueForm = () => {
    return (
        <>
            <h1>IssueForm Page</h1>
        </>
    )
}

export default IssueForm