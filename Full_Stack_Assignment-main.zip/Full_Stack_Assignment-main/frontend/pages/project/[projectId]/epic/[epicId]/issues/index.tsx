const Issues = () => {
    return (
        <>
            <h1>Issues Page</h1>
        </>
    )
}

export default Issues