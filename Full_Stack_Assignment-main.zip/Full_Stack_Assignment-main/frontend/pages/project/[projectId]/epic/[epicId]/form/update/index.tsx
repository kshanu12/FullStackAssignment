import EpicForm from "@/components/EpicForm"

const epicForm = () => {
    return (
        <>
            <EpicForm></EpicForm>
        </>
    )
}

export default epicForm