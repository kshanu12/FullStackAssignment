import IssueFormComponent from "@/components/IssueForm"

const IssueFormCreate = () => {
    return (
        <>
            <IssueFormComponent></IssueFormComponent>
        </>
    )
}

export default IssueFormCreate