import React, { useEffect, useState } from "react";
import DescriptionCard from "../../../../components/descriptionCard";
import { useRouter } from "next/router";
import { getListOfEpicBasedOnProjectId } from "../../../../method/getDataEpic";
import NoDataImage from "../../../../components/NoData";
import { Button } from "antd";
import MasterCard from "../../../../components/masterCard";
import { getProjectDataById } from "../../../../method/projectById";
import { transform } from "typescript";
import Link from "next/link";
import { log } from "console";

export default function Epic() {
  const [data, setData] = useState(null);
  const [oldprojectData, setProjectData] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [cardsPerPage, setCardsPerPage] = useState(4);

  const router = useRouter();
  const { projectId } = router.query;
  const Id = Number(projectId);
  //   console.log("query", router.query);

  useEffect(() => {
    async function fetchData() {
      const result = await getListOfEpicBasedOnProjectId(Id);
      const projectData = await getProjectDataById(Id);
      setProjectData(projectData);
      setData(result);
    }
    fetchData();
  }, []);

  // console.log(data)

  if (!data) {
    return (
      <NoDataImage
        message={"Data Is Not yet Loaded or Emply Data"}
      ></NoDataImage>
    );
  }

  console.log(data);

  const list_of_projects = data.data.res;

  console.log("shanu", data);

  if (!list_of_projects.length) {
    return (
      <>
        <MasterCard
          epicId={Id}
          title={oldprojectData.data.result.title}
          description={oldprojectData.data.result.description}
        />

        <NoDataImage
          message={"Data Is Not yet Loaded or Emply Data"}
        ></NoDataImage>
      </>
    );
  }

  // Logic for displaying current cards
  const indexOfLastCard = currentPage * cardsPerPage;
  const indexOfFirstCard = indexOfLastCard - cardsPerPage;
  const currentCards = list_of_projects.slice(
    indexOfFirstCard,
    indexOfLastCard
  );

  // Logic for displaying page numbers
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(list_of_projects.length / cardsPerPage); i++) {
    pageNumbers.push(i);
  }
  // console.log("olddata ",oldprojectData)

  const clickHandler = () => {
    router.push(`/project/${Id}/epic/create`);
  };

  return (
    <div>
      <MasterCard
        epicId={Id}
        title={oldprojectData.data.result.title}
        description={oldprojectData.data.result.description}
      />

      <Button
        style={{
          left: "45%",
          transform: "translate(-50%)",
          margin: ".5rem 2rem",
        }}
        onClick={clickHandler}
      >
        Create Epic
      </Button>
      {/* <Button style={{ left: "40%", transform: "translate(-50%)", margin: ".5rem 2rem" }}>Update</Button> */}
      {currentCards.map((each_data) => (
        // console.log("epic data:",each_data),
        <DescriptionCard
          path={`project/${each_data.projectId}/epic/${each_data.Id}`}
          key={each_data.Id}
          PageId={each_data.Id}
          title={each_data.title}
          description={each_data.description}
          epicId={each_data.epicId}
          // onClick={() => handleEpics(each_data.epicId)}
        />
      ))}
      <div>
        {pageNumbers.map((number) => (
          <Button
            style={{ margin: "1.5rem" }}
            key={number}
            onClick={() => setCurrentPage(number)}
          >
            {number}
          </Button>
        ))}
      </div>
    </div>
  );
}
