const ProjectId = () => {
    return (
        <>
            <h1>Project Id Page</h1>
        </>
    )
}

export default ProjectId