import { useEffect, useState } from "react";
import { getListOfProjectAssignedtoUser } from "../../method/descriptionCard";
import NoDataImage from "../../components/NoData";
import React from "react";
import DescriptionCard from "../../components/descriptionCard";
import { Button } from "antd";
import MasterCard from "../../components/masterCard";

export default function Projects() {
    const [data, setData] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [cardsPerPage, setCardsPerPage] = useState(4);

    useEffect(() => {
        async function fetchData() {
            const result = await getListOfProjectAssignedtoUser();
            setData(result);
        }
        fetchData();
    }, []);

    if (!data) {
        return <NoDataImage message={"No Projects Found"} />;
    }

    const list_of_projects = data.data.response;
    console.log(data);


    // Logic for displaying current cards
    const indexOfLastCard = currentPage * cardsPerPage;
    const indexOfFirstCard = indexOfLastCard - cardsPerPage;
    const currentCards = list_of_projects.slice(indexOfFirstCard, indexOfLastCard);

    // Logic for displaying page numbers
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(list_of_projects.length / cardsPerPage); i++) {
        pageNumbers.push(i);
    }




    return (
        <div >

            {currentCards.map((each_data) => (
                // console.log(each_data),

                <DescriptionCard
                    path={`project/${each_data.Id}/epic`}
                    key={each_data.Id}
                    PageId={each_data.Id}
                    title={each_data.title}
                    description={each_data.description}
                    epicId={each_data.epicId}
                // onClick={() => handleEpics(each_data.epicId)}

                />
            ))}
            <div>
                {pageNumbers.map((number) => (
                    <Button style={{ margin: "1.5rem" }} key={number} onClick={() => setCurrentPage(number)}>
                        {number}
                    </Button>
                ))}
            </div>
        </div>
    );
}
