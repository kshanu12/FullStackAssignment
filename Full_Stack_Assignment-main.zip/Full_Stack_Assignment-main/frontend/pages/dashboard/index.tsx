import CardList from "@/components/CardList"
import ChartGraph from "@/components/Chart"

const Dashboard = () => {
    return (
        <>
            <ChartGraph></ChartGraph>
            <CardList></CardList>
        </>
    )
}

export default Dashboard