import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import Headers from '../components/Header/index';

describe('Headers component', () => {
    it('renders the header and menu items', () => {
        const { getByText } = render(<Headers />);
        expect(getByText('HU PROJECT TRACKER')).toBeInTheDocument();
    });
});
