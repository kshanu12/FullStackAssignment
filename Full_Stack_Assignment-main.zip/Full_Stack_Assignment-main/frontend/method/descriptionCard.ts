import axios from "axios"

export const getListOfProjectAssignedtoUser = async () => {
    try {
        const response = await axios.get('http://localhost:3002/issue/allIssue').then((res) => {
            return res
        }).catch((error) => {
            return error
        })
        return response;
    } catch (error) {
        throw new Error(error.response.data.message);
    }
}