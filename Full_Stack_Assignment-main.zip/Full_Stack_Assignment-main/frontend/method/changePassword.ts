import axios from 'axios';

const resetPassword = async (email, oldPassword, newPassword) => {
  try {
    const response = await axios.put('http://localhost:3002/user/resetPassword', {
      email: email,
      oldPassword: oldPassword,
      newPassword: newPassword
    });
    // console.log("response :",response)
    return response;
  } catch (error) {
    throw new Error(error.response.data.message);
  }
};

export default resetPassword;
