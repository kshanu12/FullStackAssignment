import axios, { AxiosResponse } from "axios"

export const getDataPriority = () => {
    const response = axios.get('http://localhost:3002/priority').then(
        (res: AxiosResponse) => {
            return res.data.response
        }).catch((error) => {
            return error
        })
    return response
}