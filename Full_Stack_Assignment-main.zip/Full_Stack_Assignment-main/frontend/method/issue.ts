import axios, { AxiosResponse } from "axios";
import { type } from "os";

type Issue = {
    title: string,
    description: string,
    assigneeId: number,
    reporterId: number,
    typeId: number,
    statusId: number,
    priorityId: number,
    start_date: string,
    end_date: string,
    epicId: number
}

export const updateDataStatus = async (id: number, updatedStatusId: number) => {
    try {
        const response = await axios.patch(`http://localhost:3002/issue/${id}`, { statusId: updatedStatusId }).then(
            (res: AxiosResponse) => {
                return res.data.response
            }).catch((error) => {
                return error
            });
        return response.data.response;
    } catch (error) {
        console.error(error);
    }
}

export const getIssueDataById = (id: number) => {
    const response = axios.get(`http://localhost:3002/issue/issue/${id}`).then(
        (res: AxiosResponse) => {
            return res.data.response
        }).catch((error) => {
            return error
        })
    return response
}

export const postIssue = async (issue: Issue) => {
    try {
        issue.start_date = issue.start_date + "T00:00:00.000Z"
        issue.end_date = issue.end_date + "T00:00:00.000Z"
        // console.log(issue);

        const response = await axios.post(`http://localhost:3002/issue`, {
            title: issue.title,
            description: issue.description,
            assigneeId: issue.assigneeId,
            reporterId: issue.reporterId,
            typeId: issue.typeId,
            statusId: issue.statusId,
            priorityId: issue.priorityId,
            start_date: issue.start_date,
            end_date: issue.end_date,
            epicId: issue.epicId
        }).then(
            (res: AxiosResponse) => {
                return res.data.response
            }).catch((error) => {
                return error
            });
        return response.data.response;
    } catch (error) {
        console.error(error);
    }
}

export const updateIssue = async (id: number, issue: Issue) => {
    try {
        // console.log(id, typeof (id));

        issue.start_date = issue.start_date + "T00:00:00.000Z"
        issue.end_date = issue.end_date + "T00:00:00.000Z"
        const response = await axios.patch(`http://localhost:3002/issue/${id}`, {
            Id: id,
            title: issue.title,
            description: issue.description,
            assigneeId: issue.assigneeId,
            reporterId: issue.reporterId,
            typeId: issue.typeId,
            statusId: issue.statusId,
            priorityId: issue.priorityId,
            start_date: issue.start_date,
            end_date: issue.end_date,
            epicId: issue.epicId
        }).then(
            (res: AxiosResponse) => {
                return res.data.response
            }).catch((error) => {
                return error
            });
        // return response.data.response;
    } catch (error) {
        console.error(error);
    }
}