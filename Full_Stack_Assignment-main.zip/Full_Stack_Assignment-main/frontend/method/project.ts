import axios, { AxiosResponse } from "axios"


export const getProjectDataById = (id: number) => {
    const response = axios.get(`http://localhost:3002/issue/projectId/${id}`).then(
        (res: AxiosResponse) => {
            return res.data.response
        }).catch((error) => {
            return error
        })
    return response
}

export const getProjectData = () => {
    const response = axios.get('http://localhost:3002/projects').then(
        (res: AxiosResponse) => {
            return res.data.response
        }).catch((error) => {
            return error
        })
    return response
}