import axios, { AxiosResponse } from "axios";

export const getDataTypes = () => {
    const response = axios.get('http://localhost:3002/type').then(
        (res: AxiosResponse) => {
            return res.data.response
        }).catch((error) => {
            return error
        })
    return response
}