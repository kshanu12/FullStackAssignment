import axios from "axios"
import { error } from "console"

export const getListOfDataFilterAssigneeeId = async (id: number) => {
    const response = await axios.post('http://localhost:3002/issue/filter', {
        "assigneeId": id
    }).then((res) => {
        // console.log("response data",res)
        return res
    }).catch((error) => {
        return error
    })
    // console.log('response', response)
    return response
}


export const getListOfDataFiltere_Idandp_Id = async (id: number,eId:number) => {
    const response = await axios.post('http://localhost:3002/issue/filter', {
        "assigneeId": id,
        "epicId":eId
    }).then((res) => {
        // console.log("response data",res)
        return res
    }).catch((error) => {
        return error
    })
    // console.log('response', response)
    return response
}



export const deleteDataForAssigneeId = async (id: number) => {
    try {
        const response = await axios.delete(`http://localhost:3002/issue/${id}`).then((res) => {
            return res;
        }).catch((error) => {
            return error
        });
        return response
    } catch (error) {
        console.error(error);
    }
}

