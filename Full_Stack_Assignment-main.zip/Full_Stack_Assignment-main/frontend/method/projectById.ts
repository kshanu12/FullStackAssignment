
import axios from "axios"

export const getProjectDataById = async (id: number) => {
    // console.log(id)
    // console.log(typeof(id))
    try {
        const response = await axios.get(`http://localhost:3002/projects/${id}`).then((res) => {
            return res
        }).catch((error) => {
            return error
        })
        return response;
    } catch (error) {
        throw new Error(error.response.data.message);
    }
}