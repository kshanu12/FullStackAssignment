import axios, { AxiosResponse } from "axios";

export interface Epic {
    title: string;
    statusId: number;
    description: string;
    start_date: string;
    end_date: string;
    projectId: number
}


export const getEpicById = (id: number) => {
    const response = axios.get(`http://localhost:3002/epic/${id}`).then(
        (res: AxiosResponse) => {
            return res.data.result
        }).catch((error) => {
            return error
        })
    return response
}

export const postEpic = async (epic: Epic) => {
    try {
        epic.start_date = epic.start_date + "T00:00:00.000Z"
        epic.end_date = epic.end_date + "T00:00:00.000Z"
        console.log(epic);

        const response = await axios.post(`http://localhost:3002/epic`, {
            title: epic.title,
            statusId: 1,
            description: epic.description,
            start_date: epic.start_date,
            end_date: epic.end_date,
            projectId: epic.projectId
        }).then(
            (res: AxiosResponse) => {
                return res.data.response
            }).catch((error) => {
                return error
            });
        return response.data.response;
    } catch (error) {
        console.error(error);
    }
}

export const updateEpic = async (id: number, epic: Epic) => {
    try {
        epic.start_date = epic.start_date + "T00:00:00.000Z"
        epic.end_date = epic.end_date + "T00:00:00.000Z"
        const response = await axios.patch(`http://localhost:3002/epic/${id}`, {
            Id: id,
            title: epic.title,
            statusId: 1,
            description: epic.description,
            start_date: epic.start_date,
            end_date: epic.end_date,
            projectId: epic.projectId
        }).then(
            (res: AxiosResponse) => {
                return res.data.response
            }).catch((error) => {
                return error
            });
        // return response.data.response;
    } catch (error) {
        console.error(error);
    }
}


export const getUsersData = () => {
    const response = axios.get('http://localhost:3002/epic').then(
        (res: AxiosResponse) => {
            return res.data.message
        }).catch((error) => {
            return error
        })
    return response
}