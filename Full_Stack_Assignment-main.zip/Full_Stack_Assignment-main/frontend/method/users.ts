import axios, { AxiosResponse } from "axios"

export const getUsersData = () => {
    const response = axios.get('http://localhost:3002/user').then(
        (res: AxiosResponse) => {
            return res.data.message
        }).catch((error) => {
            return error
        })
    return response
}