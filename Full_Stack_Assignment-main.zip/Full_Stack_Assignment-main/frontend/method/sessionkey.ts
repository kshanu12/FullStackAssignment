import Cookies from "js-cookie";
import { useEffect, useState } from "react";

export const getUserBySessionKey = () => {
    const [user, setUser] = useState([]);

    // var session=""
    useEffect(() => {
        // Try to get the user data from sessionStorage
        const userString = sessionStorage.getItem('user');
        const userFromSession = userString ? JSON.parse(userString) : null;

        // Try to get the user data from Cookies
        // const userFromCook = Cookies.get('user');
        const userFromCookies = JSON.parse(sessionStorage.getItem('user') ?? 'null');

        // console.log("user ka token",userFromCookies);

        // Use the user data from either sessionStorage or Cookies, if it's valid
        if (userFromSession && userFromSession.user.Id && userFromSession.user.email) {
            // console.log("inside data 1",userFromCookies)
            setUser(userFromSession);
        } else if (userFromCookies && userFromCookies.user.Id && userFromCookies.user.email) {
            // console.log("inside data 2",userFromCookies)
            setUser(userFromCookies);
        }
    }, [Cookies.get('user')]);

    return user;
}