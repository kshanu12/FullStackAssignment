import axios, { AxiosResponse } from "axios"

export const getDataStatus = () => {
    const response = axios.get('http://localhost:3002/status').then(
        (res: AxiosResponse) => {
            return res.data.response
        }).catch((error) => {
            return error
        })
    return response
}