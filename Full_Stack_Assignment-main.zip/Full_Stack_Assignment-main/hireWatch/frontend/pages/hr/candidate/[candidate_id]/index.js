const CandidateID = () => {
  return (
    <>
      <h1>Candidate ID</h1>
    </>
  );
};

export default CandidateID;
