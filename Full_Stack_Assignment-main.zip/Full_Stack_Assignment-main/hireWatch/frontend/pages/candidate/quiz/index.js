const Quiz = () => {
  return (
    <>
      <h1>Quiz</h1>
    </>
  );
};

export default Quiz;
