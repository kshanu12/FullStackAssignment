const Coding = () => {
  return (
    <>
      <h1>Coding</h1>
    </>
  );
};

export default Coding;
