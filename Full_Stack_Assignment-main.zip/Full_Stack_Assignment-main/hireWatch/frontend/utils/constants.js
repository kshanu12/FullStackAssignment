export const DEPLOYED_URL = "https://hirewatch-backend-urtjok3rza-wl.a.run.app";
export const LOCAL_URL = "http://localhost:8080";
