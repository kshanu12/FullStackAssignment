# NodeJS Express

**Note:**

**1. Ensure that the application runs on port 8080. This can be achieved using `app.listen(8080);` OR `app.listen(proces.env.PORT);` since the environment variable *PORT* is set to 8080 in the Dockerfile**

**2. The *package.json* file should contain the `start` script, which will start the application server.**
